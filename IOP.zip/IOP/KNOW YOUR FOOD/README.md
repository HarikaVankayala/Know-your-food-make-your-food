# Dish-A-Day-Recipe-Website

"Learn Cook Share. Cooking Made Easy"

> Say good bye to long and frustrating food blogs and recipe videos.<br>Access our recipe cards to prepare any dish in minutes.

## The Team

- `Ashwin Narayanan S`
- `Bhojanapalli Sri Ganesh`
- `Avadhanam Sandilya Sreepadh`
- `Sajith Rajan`
- `Basam Thilaknath Reddy`
