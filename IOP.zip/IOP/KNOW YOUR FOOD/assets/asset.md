# Has Assets
- chef
- cuisines
- ingredients
- logos
- main
- team
